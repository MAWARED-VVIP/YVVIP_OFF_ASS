sap.ui.define([
	"com/adlsa/vvip/off/assg/test/unit/controller/App.controller"
], function () {
	"use strict";
});
