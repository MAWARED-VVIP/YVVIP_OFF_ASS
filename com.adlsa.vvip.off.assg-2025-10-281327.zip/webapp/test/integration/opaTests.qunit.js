/* global QUnit */
QUnit.config.autostart = false;

sap.ui.require(["com/adlsa/vvip/off/assg/test/integration/AllJourneys"
], function () {
	QUnit.start();
});
